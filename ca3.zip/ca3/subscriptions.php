<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pranjal's Blog</title>
        <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body class="bg-indigo-50">
    <div class="relative pt-6 pb-16 sm:pb-24">
      <div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6">
          <nav
            class="relative flex items-center justify-between sm:h-10 md:justify-center"
            aria-label="Global">
            <div
              class="flex items-center flex-1 md:absolute md:inset-y-0 md:left-0">
              <div class="flex items-center justify-between w-full md:w-auto">
                <a href="index.php">
                  <span class="sr-only">Pranjal's Blog</span>
                  <img class="h-8 w-auto sm:h-10" src="logo.png" alt="">
                </a>
              </div>
            </div>
            <div class="md:flex md:space-x-10 sm:align-left">
              <a href="index.php" class="font-medium text-gray-500 hover:text-gray-900">Home</a>
              <a href="subscriptions.php" class="font-medium text-gray-500 hover:text-gray-900">Subscriptions</a>
            </div>
          </nav>
        </div>

      <main>
<div class="bg-gray-100">
  <div class="max-w-7xl mx-auto py-24 px-4 sm:px-6 lg:px-8">
    <div class="sm:flex sm:flex-col sm:align-center">
      <h1 class="text-5xl font-extrabold text-gray-900 sm:text-left">Subcription Options</h1>
      <p class="mt-5 text-xl text-gray-700 sm:text-left">Kindly subscribe if you want to read other articles regularly. 
        We have 2 subscription plans available according to your choice and each subscription provides additional features. 
        It's a tier based subscription system i.e., if you unlock the second-tier you would get "Tier-1" plus extra benefits. 
        Each subscription helps me a lot. Kindly consider subscribing.</p>
    </div>
    <div class="mt-12 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-6 sm:gap-4 lg:max-w-2xl lg:mx-auto xl:max-w-none xl:mx-0 xl:grid-cols-4">
      <div class="border border-gray-400 rounded-lg shadow-sm divide-y divide-gray-400">
        <div class="p-6">
          <h2 class="text-lg leading-6 font-medium text-gray-900">Tier-1 </h2>
          <p class="mt-4 text-sm text-gray-700">This is the most basic subscription provided. </p>
          <p class="mt-8">
            <span class="text-4xl font-extrabold text-gray-900">₹49</span>
            <span class="text-base font-medium text-gray-700">/mo</span>
          </p>
          <a href="transaction.php" class="mt-8 block w-full bg-gray-800 border border-gray-800 rounded-md py-2 text-sm font-semibold text-white text-center hover:bg-gray-900">Get Tier-1 </a>
        </div>
        <div class="pt-6 pb-8 px-6">
          <h3 class="text-xs font-medium text-gray-900 tracking-wide uppercase">Benefits included: </h3>
          <ul role="list" class="mt-6 space-y-4">
            <li class="flex space-x-3">
              <svg class="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
              </svg>
              <span class="text-sm text-gray-700">E-mail notifications for each new article. </span>
            </li>

            <li class="flex space-x-3">
              <svg class="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
              </svg>
              <span class="text-sm text-gray-700">Get merchandise at 20% off. </span>
            </li>
          </ul>
        </div>
      </div>

      <div class="border border-gray-400 rounded-lg shadow-sm divide-y divide-gray-400">
        <div class="p-6">
          <h2 class="text-lg leading-6 font-medium text-gray-900">Tier-2</h2>
          <p class="mt-4 text-sm text-gray-700">The other subscription model we have. </p>
          <p class="mt-8">
            <span class="text-4xl font-extrabold text-gray-900">₹99</span>
            <span class="text-base font-medium text-gray-700">/mo</span>
          </p>
          <a href="transaction.php" class="mt-8 block w-full bg-gray-800 border border-gray-800 rounded-md py-2 text-sm font-semibold text-white text-center hover:bg-gray-900">Get Tier-2 </a>
        </div>
        <div class="pt-6 pb-8 px-6">
          <h3 class="text-xs font-medium text-gray-900 tracking-wide uppercase">Benefits included: </h3>
          <ul role="list" class="mt-6 space-y-4">
            <li class="flex space-x-3">
              <svg class="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
              </svg>
              <span class="text-sm text-gray-700">E-mail notifications for each new article. </span>
            </li>

            <li class="flex space-x-3">
              <svg class="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
              </svg>
              <span class="text-sm text-gray-700">Get merchandise at 20% off. </span>
            </li>

            <li class="flex space-x-3">
              <svg class="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
              </svg>
              <span class="text-sm text-gray-700">Get exclusive mugs after 3 months of consecutive subscriptions. </span>
            </li>
          </ul>
        </div>
      </div>

      </main>
    </div>

    <footer class="bg-indigo-50" aria-labelledby="footer-heading">
      <h2 id="footer-heading" class="sr-only">Footer</h2>
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
          <div class="mt-12 border-t border-gray-100 pt-8">
            <p class="text-base text-gray-400 xl:text-center">
              &copy; 2022 Pranjal's Blog, Inc. All rights reserved.
            </p>
          </div>
        </div>
    </footer>

</body>
</html>