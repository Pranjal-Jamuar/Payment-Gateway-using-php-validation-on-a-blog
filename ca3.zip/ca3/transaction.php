<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pranjal's Blog</title>
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body class="bg-indigo-50">
    <?php 
      $NumError = $NameError = $CvvError = "";
      $CardValid =  $ValidName = $ValidCvv = false;

      function cardValidation($num)
      {
          global $type;
          global $NumError;

          $cardtype = array(
              "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
              "mastercard" => "/^5[1-5][0-9]{14}$/",
          );

          if (preg_match($cardtype['visa'],$num))
          {
        $type= "visa";
              return true;
        
          }
          else if (preg_match($cardtype['mastercard'],$num))
          {
        $type= "mastercard";
              return true;
          }
          else
          {
              $NumError = "Card number invalid!";
              return false;
          } 
      }
      function nameValidation($Name)
{
   global $NameError;
    if (empty($Name))
    {
        $NameError = "Error!! Kindly enter the name on the card";
        return false;
    }
    elseif (!preg_match("/^[a-zA-Z]*$/",$Name))
    {
        $NameError = "Only alphabets and spaces are allowed";
        return false;
    }
    else
    {
        return true;
    }
}

function cvvValidation($cvv)
{
    global $CvvError;
     if (empty($cvv))
    {
        $CvvError = "Error!! Kindly enter the cvv. It should be on the back of your card.";
        return false;
    }
    elseif(!preg_match("/^[0-9]*$/",$cvv))
    {
       $CvvError= "Only numeric values are allowed";
       return false;
    } elseif (strlen($cvv)<3 && strlen($cvv)>5)
    {
       $CvvError = "cvv ranges between 3 to 5";
       return false;
    }
    else
    {
        return true;

    }
}

      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $num= $_POST['card-number'];
        $Name= $_POST['name-on-card'];
        $cvv= $_POST['cvv'];
        $CardValid = cardValidation($num);
        $ValidName = nameValidation($Name);
        $ValidCvv = cvvValidation($cvv);
      }

    ?>
    <div class="relative pt-6 pb-16 sm:pb-24">
      <div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6">
          <nav
            class="relative flex items-center justify-between sm:h-10 md:justify-center"
            aria-label="Global">
            <div
              class="flex items-center flex-1 md:absolute md:inset-y-0 md:left-0">
              <div class="flex items-center justify-between w-full md:w-auto">
                <a href="index.php">
                  <span class="sr-only">Pranjal's Blog</span>
                  <img class="h-8 w-auto sm:h-10" src="logo.png" alt="">
                </a>
              </div>
            </div>
            <div class="hidden md:flex md:space-x-10">
              <a href="index.php" class="font-medium text-gray-500 hover:text-gray-900">Home</a>
              <a href="subscriptions.php"class="font-medium text-gray-500 hover:text-gray-900">Subscriptions</a>
            </div>
          </nav>
        </div>

      <main>
        <div class="sm:mx-auto sm:w-full sm:max-w-md mt-16">
          <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Payment Options
          </h2>
        </div>
        <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div class="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
            <form class="space-y-6" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
              <?php if($CardValid && $ValidName && $ValidCvv): ?>
                <div class="rounded-md bg-green-50 p-4">
                  <div class="flex">
                    <div class="flex-shrink-0">
                      <svg class="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                      </svg>
                    </div>
                          <div class="ml-3">
                            <p class="text-sm font-medium text-green-800">Successfully subscribed!</p>
                          </div>
                    </div>
                  </div>
              <?php endif; ?>
              
<div>
  <h2 class="text-lg font-medium text-gray-900">Payment by:</h2>
  <fieldset class="mt-4">
                  <legend class="sr-only">Payment type</legend>
                  <div class="space-y-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-10">
                    <div class="flex items-center">
                      <input
                        id="credit-card"
                        name="payment-type"
                        type="radio"
                        checked
                        class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                      />
                      <label
                        for="credit-card"
                        class="ml-3 block text-sm font-medium text-gray-700"
                      >
                        Credit card
                      </label>
                    </div>

                    <div class="flex items-center">
                      <input
                        id="debit-card"
                        name="payment-type"
                        type="radio"
                        class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                      />
                      <label
                        for="debit-card"
                        class="ml-3 block text-sm font-medium text-gray-700"
                      >
                        Debit Card
                      </label>
                    </div>
                  </div>
                </fieldset>

                <div class="mt-6 grid grid-cols-4 gap-y-6 gap-x-4">
                  <div class="col-span-4">
                    <label
                      for="card-number"
                      class="block text-sm font-medium text-gray-700"
                      >Card number</label
                    >
                    <div class="mt-1">
                      <input
                        type="text"
                        id="card-number"
                        name="card-number"
                        autocomplete="cc-number"
                        class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                      />
                      <p class="mt-2 text-sm text-red-600" ><?php echo $NumError; ?></p>
                    </div>
                  </div>

                  <div class="col-span-4">
                    <label
                      for="name-on-card"
                      class="block text-sm font-medium text-gray-700"
                      >Name on Card</label
                    >
                    <div class="mt-1">
                      <input
                        type="text"
                        id="name-on-card"
                        name="name-on-card"
                        autocomplete="cc-name"
                        class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                      />
                                            <p class="mt-2 text-sm text-red-600" ><?php echo $NameError; ?></p>

                    </div>
                  </div>

                  <div class="col-span-3">
                    <label
                      for="expiration-date"
                      class="block text-sm font-medium text-gray-700"
                      >Expiration date (mm/yy)</label
                    >
                    <div class="mt-1">
                      <input
                        type="text"
                        name="expiration-date"
                        id="expiration-date"
                        autocomplete="cc-exp"
                        class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      for="cvv"
                      class="block text-sm font-medium text-gray-700"
                      >cvv</label
                    >
                    <div class="mt-1">
                      <input
                        type="text"
                        name="cvv"
                        id="cvv"
                        autocomplete="csc"
                        class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                      />
                    </div>
                  </div>
                </div>
                <p class="mt-2 text-sm text-red-600 text-right" ><?php echo $CvvError; ?></p>
              </div>

              <div>
                <button
                  type="submit"
                  class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Subscribe
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
    <footer class="bg-indigo-50" aria-labelledby="footer-heading">
      <h2 id="footer-heading" class="sr-only">Footer</h2>
        <div class="mt-12 border-t pt-8">
          <p class="text-base text-gray-400 xl:text-center">
            &copy; 2022 Pranjal's Blog, Inc. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  </body>
</html>
